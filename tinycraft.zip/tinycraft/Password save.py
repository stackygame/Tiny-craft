password=input("enter password then copy paste to a folder")
print(password)