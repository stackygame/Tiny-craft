#include <iostream>
#include <fstream>
#include <string>
#include <unordered_map>

using namespace std;

// Function to load user credentials from a file
unordered_map<string, string> loadCredentials(const string& filename) {
    unordered_map<string, string> credentials;
    ifstream file(filename);

    if (file.is_open()) {
        string username, password;
        while (file >> username >> password) {
            credentials[username] = password;
        }
        file.close();
    } else {
        cout << "Error: Unable to open the file.\n";
    }

    return credentials;
}

// Function to validate login
bool validateLogin(const unordered_map<string, string>& credentials, const string& username, const string& password) {
    auto it = credentials.find(username);
    if (it != credentials.end() && it->second == password) {
        return true;  // Valid login
    }
    return false;  // Invalid login
}

// Main function
int main() {
    const string filename = "credentials.txt";

    // Load credentials from the file
    unordered_map<string, string> credentials = loadCredentials(filename);

    // Display login page
    cout << "===== Login Page =====\n";
    string username, password;
    cout << "Enter username: ";
    cin >> username;
    cout << "Enter password: ";
    cin >> password;

    // Validate credentials
    if (validateLogin(credentials, username, password)) {
        cout << "Login successful! Welcome, " << username << ".\n";
    } else {
        cout << "Invalid username or password. Please try again.\n";
    }

    return 0;
}
